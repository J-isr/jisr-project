ALTER TYPE public.member_status ADD VALUE IF NOT EXISTS 'rejected';
ALTER TYPE public.member_status ADD VALUE IF NOT EXISTS 'suspended';