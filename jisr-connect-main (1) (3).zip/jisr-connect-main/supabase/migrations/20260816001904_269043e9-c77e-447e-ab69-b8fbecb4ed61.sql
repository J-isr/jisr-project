-- 1. Membership application fields on the existing members table
ALTER TABLE public.members
  ADD COLUMN IF NOT EXISTS college text,
  ADD COLUMN IF NOT EXISTS academic_level text,
  ADD COLUMN IF NOT EXISTS interests text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS recommended_committee_id uuid REFERENCES public.committees(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS assigned_committee_id uuid REFERENCES public.committees(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS applied_at timestamptz,
  ADD COLUMN IF NOT EXISTS reviewed_at timestamptz,
  ADD COLUMN IF NOT EXISTS reviewed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS rejection_reason text;

CREATE UNIQUE INDEX IF NOT EXISTS members_user_id_key ON public.members(user_id) WHERE user_id IS NOT NULL;

-- 2. Achievements: type + image/certificate
ALTER TABLE public.achievements
  ADD COLUMN IF NOT EXISTS achievement_type text NOT NULL DEFAULT 'other',
  ADD COLUMN IF NOT EXISTS image_url text;

-- 3. Users may submit their own membership application (always pending)
DROP POLICY IF EXISTS "Users can apply for membership" ON public.members;
CREATE POLICY "Users can apply for membership"
ON public.members FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid() AND status = 'pending');

-- 4. Guard privileged member columns against self-service edits
CREATE OR REPLACE FUNCTION public.protect_member_privileged_fields()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF public.is_admin() THEN
    RETURN NEW;
  END IF;

  NEW.status := OLD.status;
  NEW.assigned_committee_id := OLD.assigned_committee_id;
  NEW.member_number := OLD.member_number;
  NEW.reviewed_at := OLD.reviewed_at;
  NEW.reviewed_by := OLD.reviewed_by;
  NEW.rejection_reason := OLD.rejection_reason;
  NEW.joined_at := OLD.joined_at;
  NEW.is_public := OLD.is_public;
  NEW.user_id := OLD.user_id;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_members_protect_fields ON public.members;
CREATE TRIGGER trg_members_protect_fields
BEFORE UPDATE ON public.members
FOR EACH ROW EXECUTE FUNCTION public.protect_member_privileged_fields();

-- 5. Admin visibility for dashboard counts and role management
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
CREATE POLICY "Admins can view all profiles"
ON public.profiles FOR SELECT TO authenticated
USING (public.is_admin());

DROP POLICY IF EXISTS "Admins manage user roles" ON public.user_roles;
CREATE POLICY "Admins manage user roles"
ON public.user_roles FOR ALL TO authenticated
USING (public.is_admin()) WITH CHECK (public.is_admin());

GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_roles TO authenticated;