import { Container } from "@/components/common/Container";
import { SectionHeader } from "@/components/common/SectionHeader";
import { EmptyState } from "@/components/common/EmptyState";
import { useLanguage } from "@/hooks/useLanguage";

/** Shared shell for pages whose content arrives in a later phase. */
export function PagePlaceholder({ title, subtitle }: { title: string; subtitle: string }) {
  const { t } = useLanguage();

  return (
    <Container className="py-16 sm:py-20">
      <SectionHeader eyebrow="JISR" title={title} subtitle={subtitle} />
      <div className="mt-10">
        <EmptyState title={t.common.empty} description={t.common.emptyHint} />
      </div>
    </Container>
  );
}
