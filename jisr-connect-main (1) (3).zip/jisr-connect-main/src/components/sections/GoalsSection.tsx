import { Container } from "@/components/common/Container";
import { SectionHeader } from "@/components/common/SectionHeader";
import { GoalCard } from "@/components/common/GoalCard";
import { goals } from "@/config/content";
import { useLanguage } from "@/hooks/useLanguage";

export function GoalsSection() {
  const { t } = useLanguage();

  return (
    <section className="py-16 sm:py-24">
      <Container>
        <SectionHeader title={t.sections.goalsTitle} subtitle={t.sections.goalsSubtitle} align="center" />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {goals.map((goal, index) => (
            <GoalCard key={goal.key} goal={goal} index={index} />
          ))}
        </div>
      </Container>
    </section>
  );
}
