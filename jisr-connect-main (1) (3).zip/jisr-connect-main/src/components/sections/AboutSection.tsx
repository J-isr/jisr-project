import { Compass, Target } from "lucide-react";
import { Container } from "@/components/common/Container";
import { SectionHeader } from "@/components/common/SectionHeader";
import { AffiliationLogos } from "@/components/common/AffiliationLogos";

import { aboutContent, missionContent, visionContent } from "@/config/content";
import { useLanguage } from "@/hooks/useLanguage";

export function AboutSection() {
  const { t, language } = useLanguage();
  const isAr = language === "ar";

  return (
    <section id="about" className="scroll-mt-24 py-16 sm:py-24">
      <Container>
        <SectionHeader eyebrow={t.sections.aboutEyebrow} title={t.sections.aboutTitle} align="center" className="mx-auto" />
        <p className="mx-auto mt-8 max-w-3xl text-center text-lg leading-loose text-foreground/85">
          {isAr ? aboutContent.ar : aboutContent.en}
        </p>

        <div className="mt-14 grid gap-6 md:grid-cols-2">
          <article className="surface-card p-8">
            <span className="flex size-12 items-center justify-center rounded-2xl bg-brand-blue-soft text-brand-blue">
              <Compass className="size-5" aria-hidden="true" />
            </span>
            <h3 className="mt-5 text-xl font-semibold text-foreground">{t.sections.visionTitle}</h3>
            <p className="mt-3 text-sm leading-loose text-muted-foreground">
              {isAr ? visionContent.ar : visionContent.en}
            </p>
          </article>

          <article className="surface-card p-8">
            <span className="flex size-12 items-center justify-center rounded-2xl bg-gold-soft text-accent-foreground">
              <Target className="size-5" aria-hidden="true" />
            </span>
            <h3 className="mt-5 text-xl font-semibold text-foreground">{t.sections.missionTitle}</h3>
            <p className="mt-3 text-sm leading-loose text-muted-foreground">
              {isAr ? missionContent.ar : missionContent.en}
            </p>
          </article>
        </div>

        <div className="mt-14 flex flex-col items-center gap-5 rounded-3xl border border-border bg-secondary/40 px-6 py-8">
          <h3 className="text-xs font-semibold tracking-[0.2em] text-muted-foreground uppercase">
            {t.footer.affiliation}
          </h3>
          <AffiliationLogos className="justify-center" />
        </div>

      </Container>
    </section>
  );
}
