import { Container } from "@/components/common/Container";
import { SectionHeader } from "@/components/common/SectionHeader";
import { EventCard } from "@/components/common/EventCard";
import { initiatives } from "@/config/content";
import { useLanguage } from "@/hooks/useLanguage";

export function EventsSection() {
  const { t } = useLanguage();

  return (
    <section className="bg-secondary/40 py-16 sm:py-24">
      <Container>
        <SectionHeader title={t.sections.eventsTitle} subtitle={t.sections.eventsSubtitle} align="center" />
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {initiatives.map((item) => (
            <EventCard key={item.key} item={item} />
          ))}
        </div>
      </Container>
    </section>
  );
}
