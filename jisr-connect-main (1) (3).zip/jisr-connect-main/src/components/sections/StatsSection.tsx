import { Container } from "@/components/common/Container";
import { StatCard } from "@/components/common/StatCard";
import { statistics } from "@/config/stats";
import { useLanguage } from "@/hooks/useLanguage";

export function StatsSection() {
  const { t } = useLanguage();

  return (
    <section aria-label={t.sections.statsTitle} className="border-y border-border bg-secondary/50 py-14">
      <Container>
        <div className="grid gap-4 sm:grid-cols-3">
          {statistics.map((stat) => (
            <StatCard key={stat.key} stat={stat} />
          ))}
        </div>
      </Container>
    </section>
  );
}
