import { Container } from "@/components/common/Container";
import { Button } from "@/components/ui/button";
import { clubConfig } from "@/config/club";
import { useLanguage } from "@/hooks/useLanguage";

export function CTASection() {
  const { t } = useLanguage();

  return (
    <section className="py-16 sm:py-24">
      <Container>
        <div className="gradient-hero rounded-[var(--radius-4xl)] px-6 py-16 text-center sm:px-12">
          <h2 className="font-display text-3xl font-bold text-primary-foreground sm:text-4xl">
            {t.sections.ctaTitle}
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-primary-foreground/80">
            {t.sections.ctaSubtitle}
          </p>
          <Button asChild variant="gold" size="lg" className="mt-8">
            <a href={clubConfig.joinFormUrl} target="_blank" rel="noopener noreferrer">
              {t.hero.primaryCta}
            </a>
          </Button>
        </div>
      </Container>
    </section>
  );
}
