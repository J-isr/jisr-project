import { ArrowLeft, ArrowRight } from "lucide-react";
import { Container } from "@/components/common/Container";
import { Logo } from "@/components/common/Logo";
import { Button } from "@/components/ui/button";
import { clubConfig } from "@/config/club";
import { slogan } from "@/config/content";
import { useLanguage } from "@/hooks/useLanguage";

export function Hero() {
  const { t, language, isRTL } = useLanguage();
  const Arrow = isRTL ? ArrowLeft : ArrowRight;

  return (
    <section className="relative overflow-hidden gradient-hero">
      <Container className="relative py-20 sm:py-28">
        <p className="text-xs font-semibold tracking-[0.25em] text-accent uppercase">
          {language === "ar" ? clubConfig.universityAr : clubConfig.universityEn}
        </p>

        <p className="mt-4 text-lg font-semibold text-primary-foreground sm:text-xl">
          {t.hero.welcome}
        </p>

        <Logo inverted className="mt-6" markClassName="h-16 max-w-[220px] sm:h-20 sm:max-w-[280px]" showWordmark={false} />

        <h1 className="mt-6 font-display text-4xl font-bold text-primary-foreground sm:text-6xl">
          {clubConfig.nameEn} <span className="text-accent">|</span> {clubConfig.nameAr}
        </h1>

        <p className="mt-5 max-w-3xl text-xl leading-relaxed font-semibold text-accent sm:text-2xl">
          {slogan.ar}
        </p>
        {language === "en" ? (
          <p className="mt-2 max-w-2xl text-base text-primary-foreground/70">{slogan.en}</p>
        ) : null}

        <p className="mt-6 max-w-2xl text-base leading-relaxed text-primary-foreground/80 sm:text-lg">
          {t.hero.intro}
        </p>

        <div className="mt-9 flex flex-wrap gap-3">
          <Button asChild variant="gold" size="lg">
            <a href={clubConfig.joinFormUrl} target="_blank" rel="noopener noreferrer">
              {t.hero.primaryCta}
            </a>
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="border-primary-foreground/30 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
          >
            <a href="#about">
              {t.hero.secondaryCta}
              <Arrow className="size-4" aria-hidden="true" />
            </a>
          </Button>
        </div>
      </Container>
    </section>
  );
}
