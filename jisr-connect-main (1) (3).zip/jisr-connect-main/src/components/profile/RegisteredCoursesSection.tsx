import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { CalendarDays, GraduationCap, MapPin } from "lucide-react";
import { EmptyState } from "@/components/common/EmptyState";
import { CardSkeleton } from "@/components/common/LoadingSkeleton";
import { ErrorState } from "@/components/common/ErrorState";
import { SectionHeader } from "@/components/common/SectionHeader";
import { useLanguage } from "@/hooks/useLanguage";
import { registrationService } from "@/services/registrationService";
import { formatDate, pickLocalized } from "@/utils/format";

export function RegisteredCoursesSection({ memberId }: { memberId: string | null }) {
  const { t, language } = useLanguage();

  const { data, isPending, isError, refetch } = useQuery({
    queryKey: ["my-registrations", memberId],
    queryFn: () => registrationService.listMine(memberId),
    enabled: Boolean(memberId),
    retry: false,
  });

  const items = data ?? [];
  const statusLabels = t.statuses as Record<string, string>;

  return (
    <section className="space-y-6">
      <SectionHeader title={t.myCourses.title} />

      {!memberId ? (
        <EmptyState title={t.myCourses.empty} icon={<GraduationCap className="size-5" />} />
      ) : isPending ? (
        <div className="grid gap-4 sm:grid-cols-2">
          <CardSkeleton />
          <CardSkeleton />
        </div>
      ) : isError ? (
        <ErrorState onRetry={() => void refetch()} />
      ) : items.length === 0 ? (
        <EmptyState title={t.myCourses.empty} icon={<GraduationCap className="size-5" />} />
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2">
          {items.map((item) => {
            const event = item.events;
            if (!event) return null;
            const row = event as unknown as Record<string, unknown>;
            return (
              <li key={item.id} className="surface-card overflow-hidden">
                {event.cover_image_url ? (
                  <img
                    src={event.cover_image_url}
                    alt={pickLocalized(row, "title", language)}
                    loading="lazy"
                    className="h-36 w-full object-cover"
                  />
                ) : null}
                <div className="space-y-2 p-5">
                  <h3 className="text-base font-semibold text-foreground">
                    <Link to="/events/$id" params={{ id: event.id }} className="hover:underline">
                      {pickLocalized(row, "title", language)}
                    </Link>
                  </h3>
                  {event.starts_at ? (
                    <p className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CalendarDays className="size-4 text-accent" aria-hidden="true" />
                      {formatDate(event.starts_at, language)}
                    </p>
                  ) : null}
                  {event.location_ar || event.location_en ? (
                    <p className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="size-4 text-accent" aria-hidden="true" />
                      {pickLocalized(row, "location", language)}
                    </p>
                  ) : null}
                  <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-muted-foreground">
                    <span className="rounded-full bg-brand-blue-soft px-3 py-1 font-semibold text-brand-blue">
                      {statusLabels[item.status] ?? item.status}
                    </span>
                    <span>
                      {t.myCourses.registeredAt}: {formatDate(item.registered_at, language)}
                    </span>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
