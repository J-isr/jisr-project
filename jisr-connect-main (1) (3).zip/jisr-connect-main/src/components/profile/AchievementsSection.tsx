import { useQuery } from "@tanstack/react-query";
import { Award } from "lucide-react";
import { EmptyState } from "@/components/common/EmptyState";
import { CardSkeleton } from "@/components/common/LoadingSkeleton";
import { ErrorState } from "@/components/common/ErrorState";
import { SectionHeader } from "@/components/common/SectionHeader";
import { useLanguage } from "@/hooks/useLanguage";
import { achievementService } from "@/services/achievementService";
import { formatDate, pickLocalized } from "@/utils/format";

export function AchievementsSection({ memberId }: { memberId: string | null }) {
  const { t, language } = useLanguage();

  const { data, isPending, isError, refetch } = useQuery({
    queryKey: ["my-achievements", memberId],
    queryFn: () => achievementService.listForMember(memberId),
    enabled: Boolean(memberId),
    retry: false,
  });

  const items = data ?? [];
  const typeLabels = t.achievements.types as Record<string, string>;

  return (
    <section className="space-y-6">
      <SectionHeader title={t.achievements.title} />

      {!memberId ? (
        <EmptyState title={t.achievements.empty} icon={<Award className="size-5" />} />
      ) : isPending ? (
        <div className="grid gap-4 sm:grid-cols-2">
          <CardSkeleton />
          <CardSkeleton />
        </div>
      ) : isError ? (
        <ErrorState onRetry={() => void refetch()} />
      ) : items.length === 0 ? (
        <EmptyState title={t.achievements.empty} icon={<Award className="size-5" />} />
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2">
          {items.map((item) => (
            <li key={item.id} className="surface-card overflow-hidden">
              {item.image_url ? (
                <img
                  src={item.image_url}
                  alt={pickLocalized(item as unknown as Record<string, unknown>, "title", language)}
                  loading="lazy"
                  className="h-36 w-full object-cover"
                />
              ) : null}
              <div className="space-y-2 p-5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-full bg-gold-soft px-3 py-1 text-xs font-semibold text-accent-foreground">
                    {typeLabels[item.achievement_type] ?? typeLabels["other"]}
                  </span>
                  {item.awarded_at ? (
                    <span className="text-xs text-muted-foreground">
                      {formatDate(item.awarded_at, language)}
                    </span>
                  ) : null}
                </div>
                <h3 className="text-base font-semibold text-foreground">
                  {pickLocalized(item as unknown as Record<string, unknown>, "title", language)}
                </h3>
                {item.description_ar || item.description_en ? (
                  <p className="text-sm leading-relaxed text-muted-foreground">
                    {pickLocalized(
                      item as unknown as Record<string, unknown>,
                      "description",
                      language,
                    )}
                  </p>
                ) : null}
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
