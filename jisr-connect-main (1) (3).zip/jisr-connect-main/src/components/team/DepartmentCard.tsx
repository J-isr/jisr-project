import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";
import { CommitteeCard } from "./CommitteeCard";
import { pick, type Department } from "@/types/committees";
import { cn } from "@/lib/utils";

interface DepartmentCardProps {
  department: Department;
  defaultOpen?: boolean;
}

export function DepartmentCard({ department, defaultOpen = false }: DepartmentCardProps) {
  const { language, t } = useLanguage();
  const [open, setOpen] = useState(defaultOpen);
  const panelId = `dept-${department.id}`;

  return (
    <section className="surface-card overflow-hidden">
      <div className="flex flex-col gap-4 p-6 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <h3 className="text-xl font-bold text-foreground">{pick(department.name, language)}</h3>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
            {pick(department.overview, language)}
          </p>
          <p className="mt-3 font-mono text-xs text-accent">
            {department.committees.length} {t.team.committeesCount}
          </p>
        </div>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls={panelId}
          className="inline-flex shrink-0 items-center gap-2 self-start rounded-full border border-accent/50 bg-gold-soft px-4 py-2 text-sm font-semibold text-accent-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
        >
          {open ? t.team.hideDetails : t.team.details}
          <ChevronDown
            aria-hidden="true"
            className={cn("size-4 transition-transform", open && "rotate-180")}
          />
        </button>
      </div>

      {open ? (
        <div id={panelId} className="border-t border-border bg-muted/30 p-6">
          <h4 className="sr-only">{t.team.committees}</h4>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {department.committees.map((committee) => (
              <CommitteeCard key={committee.id} committee={committee} />
            ))}
          </div>
        </div>
      ) : null}
    </section>
  );
}
