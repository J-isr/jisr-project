import { useMemo, useState } from "react";
import { ArrowRight, RotateCcw, Sparkles } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";
import { Button } from "@/components/ui/button";
import { clubConfig } from "@/config/club";
import { matcherQuestions, scoreAnswers } from "@/config/matcher";
import { pick, type MatcherOption } from "@/types/committees";
import { cn } from "@/lib/utils";

export function CommitteeMatcher() {
  const { language, t } = useLanguage();
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<MatcherOption[]>([]);

  const total = matcherQuestions.length;
  const finished = answers.length === total;
  const result = useMemo(() => (finished ? scoreAnswers(answers) : null), [finished, answers]);

  const select = (option: MatcherOption) => {
    const next = [...answers.slice(0, step), option];
    setAnswers(next);
    if (step < total - 1) setStep(step + 1);
  };

  const reset = () => {
    setAnswers([]);
    setStep(0);
  };

  const question = matcherQuestions[step] ?? matcherQuestions[0]!;

  return (
    <section
      aria-labelledby="matcher-title"
      className="surface-card overflow-hidden p-6 sm:p-8"
    >
      <header className="flex flex-col gap-2">
        <span className="inline-flex w-fit items-center gap-2 rounded-full border border-accent/40 bg-gold-soft px-3 py-1 text-xs font-semibold text-accent-foreground">
          <Sparkles className="size-3.5" aria-hidden="true" />
          {t.matcher.title}
        </span>
        <h2 id="matcher-title" className="text-2xl font-bold text-foreground sm:text-3xl">
          {t.matcher.title}
        </h2>
        <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground">
          {t.matcher.subtitle}
        </p>
      </header>

      {!finished ? (
        <div className="mt-6">
          <div
            role="progressbar"
            aria-valuemin={1}
            aria-valuemax={total}
            aria-valuenow={step + 1}
            aria-label={t.matcher.progress
              .replace("{current}", String(step + 1))
              .replace("{total}", String(total))}
            className="h-2 w-full overflow-hidden rounded-full bg-muted"
          >
            <div
              className="h-full rounded-full bg-accent transition-[width] duration-300"
              style={{ width: `${((step + 1) / total) * 100}%` }}
            />
          </div>
          <p className="mt-2 font-mono text-xs text-muted-foreground">
            {t.matcher.progress
              .replace("{current}", String(step + 1))
              .replace("{total}", String(total))}
          </p>

          <h3 className="mt-5 text-lg font-semibold text-foreground">
            {pick(question.question, language)}
          </h3>

          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {question.options.map((option) => {
              const active = answers[step]?.id === option.id;
              return (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => select(option)}
                  className={cn(
                    "rounded-2xl border border-border bg-card p-4 text-start text-sm font-medium text-foreground transition-all hover:-translate-y-0.5 hover:border-accent/60 hover:shadow-[var(--shadow-soft)]",
                    active && "border-accent bg-gold-soft",
                  )}
                >
                  {pick(option.label, language)}
                </button>
              );
            })}
          </div>

          {step > 0 ? (
            <Button variant="ghost" size="sm" className="mt-4" onClick={() => setStep(step - 1)}>
              {t.matcher.back}
            </Button>
          ) : null}
        </div>
      ) : (
        <div className="mt-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
          {result ? (
            <div className="rounded-2xl border border-accent/50 bg-gold-soft p-6">
              <p className="text-sm font-medium text-muted-foreground">{t.matcher.resultLabel}</p>
              <h3 className="mt-1 text-2xl font-bold text-foreground">
                {pick(result.committee.name, language)}
              </h3>
              <p className="mt-1 font-mono text-xs text-accent">
                {pick(result.department.name, language)}
              </p>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                {pick(result.committee.description, language)}
              </p>
              <div className="mt-4">
                <p className="text-sm font-semibold text-foreground">{t.matcher.resultBecause}</p>
                <ul className="mt-2 list-disc space-y-1 ps-5 text-sm text-muted-foreground">
                  {result.reasons.map((reason) => (
                    <li key={reason.en}>{pick(reason, language)}</li>
                  ))}
                </ul>
              </div>
              <div className="mt-6 flex flex-wrap gap-3">
                <Button asChild>
                  <a href={clubConfig.joinFormUrl} target="_blank" rel="noreferrer noopener">
                    {t.matcher.join}
                    <ArrowRight className="size-4 rtl:rotate-180" aria-hidden="true" />
                  </a>
                </Button>
                <Button variant="outline" onClick={reset}>
                  <RotateCcw className="size-4" aria-hidden="true" />
                  {t.matcher.retake}
                </Button>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl border border-border p-6 text-center">
              <p className="text-sm text-muted-foreground">{t.matcher.noMatch}</p>
              <Button variant="outline" className="mt-4" onClick={reset}>
                {t.matcher.retake}
              </Button>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
