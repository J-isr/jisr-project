import { useLanguage } from "@/hooks/useLanguage";
import { JisrCard } from "@/components/common/JisrCard";
import { pick, type Committee } from "@/types/committees";

export function CommitteeCard({ committee }: { committee: Committee }) {
  const { language } = useLanguage();
  return (
    <JisrCard interactive className="h-full">
      <h4 className="flex items-center gap-2 text-base font-semibold text-foreground">
        <span aria-hidden="true" className="font-mono text-accent">&lt;/&gt;</span>
        {pick(committee.name, language)}
      </h4>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
        {pick(committee.description, language)}
      </p>
    </JisrCard>
  );
}
