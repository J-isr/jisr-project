import { Link } from "@tanstack/react-router";
import { BadgeCheck, Clock, ShieldX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/hooks/useLanguage";
import type { Member } from "@/services/membershipService";
import { formatDate, pickLocalized } from "@/utils/format";

interface Props {
  member: Member | null;
  committees?: { id: string; name_ar: string; name_en: string | null }[];
  showApplyCta?: boolean;
}

export function MembershipStatusCard({ member, committees = [], showApplyCta = true }: Props) {
  const { t, language } = useLanguage();

  const messages: Record<string, string> = {
    pending: t.membership.pendingMsg,
    active: t.membership.approvedMsg,
    rejected: t.membership.rejectedMsg,
    suspended: t.membership.suspendedMsg,
    alumni: t.membership.alumniMsg,
    inactive: t.membership.inactiveMsg,
  };

  const status = member?.status ?? null;
  const message = status ? (messages[status] ?? t.membership.notAppliedMsg) : t.membership.notAppliedMsg;

  const Icon = status === "active" ? BadgeCheck : status === "pending" ? Clock : ShieldX;

  const committeeName = (id: string | null | undefined) => {
    if (!id) return t.membership.none;
    const committee = committees.find((c) => c.id === id);
    if (!committee) return t.membership.none;
    return pickLocalized(committee as unknown as Record<string, unknown>, "name", language);
  };

  return (
    <div className="surface-card space-y-4 p-6">
      <div className="flex items-center gap-3">
        <span className="flex size-10 items-center justify-center rounded-full bg-gold-soft text-accent-foreground">
          <Icon className="size-5" aria-hidden="true" />
        </span>
        <div>
          <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
            {t.membership.statusTitle}
          </p>
          <p className="text-base font-semibold text-foreground">{message}</p>
        </div>
      </div>

      {member ? (
        <dl className="grid gap-4 text-sm sm:grid-cols-2">
          <div>
            <dt className="text-xs text-muted-foreground">{t.membership.appliedAt}</dt>
            <dd className="text-foreground">
              {member.applied_at ? formatDate(member.applied_at, language) : t.membership.none}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">{t.membership.memberSince}</dt>
            <dd className="text-foreground">
              {member.joined_at ? formatDate(member.joined_at, language) : t.membership.none}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">{t.membership.recommendedCommittee}</dt>
            <dd className="text-foreground">{committeeName(member.recommended_committee_id)}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">{t.membership.assignedCommittee}</dt>
            <dd className="text-foreground">{committeeName(member.assigned_committee_id)}</dd>
          </div>
        </dl>
      ) : showApplyCta ? (
        <Button asChild variant="gold" size="sm">
          <Link to="/membership">{t.membership.apply}</Link>
        </Button>
      ) : null}
    </div>
  );
}
