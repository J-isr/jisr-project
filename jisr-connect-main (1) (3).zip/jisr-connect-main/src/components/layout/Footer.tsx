import { Link } from "@tanstack/react-router";
import { Instagram, Linkedin, Mail, MapPin, Music2 } from "lucide-react";
import type { ComponentType } from "react";
import { Container } from "@/components/common/Container";
import { Logo } from "@/components/common/Logo";
import { AffiliationLogos } from "@/components/common/AffiliationLogos";
import { contactConfig, hasPhone } from "@/config/contact";
import { activeSocialLinks, type SocialPlatform } from "@/config/social";
import { navItems } from "@/config/navigation";
import { useLanguage } from "@/hooks/useLanguage";

const icons: Partial<Record<SocialPlatform, ComponentType<{ className?: string }>>> = {
  instagram: Instagram,
  linkedin: Linkedin,
  tiktok: Music2,
};

export function Footer() {
  const { t, language } = useLanguage();
  const year = new Date().getFullYear();

  return (
    <footer className="mt-24 border-t border-border bg-secondary/60">
      <Container className="grid gap-10 py-14 md:grid-cols-3">
        <div>
          <Logo />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
            {t.footer.about}
          </p>
        </div>


        <nav aria-label={t.footer.quickLinks}>
          <h2 className="text-sm font-semibold text-foreground">{t.footer.quickLinks}</h2>
          <ul className="mt-4 grid grid-cols-2 gap-2">
            {navItems.map((item) => (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className="text-sm text-muted-foreground transition-colors hover:text-brand-blue"
                >
                  {t.nav[item.key]}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h2 className="text-sm font-semibold text-foreground">{t.footer.contact}</h2>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <Mail className="size-4 shrink-0" aria-hidden="true" />
              <a href={`mailto:${contactConfig.email}`} className="hover:text-brand-blue">
                {contactConfig.email}
              </a>
            </li>
            {hasPhone ? <li>{contactConfig.phone}</li> : null}
            <li className="flex items-center gap-2">
              <MapPin className="size-4 shrink-0" aria-hidden="true" />
              <span>{language === "ar" ? contactConfig.locationAr : contactConfig.locationEn}</span>
            </li>
          </ul>

          <h2 className="mt-6 text-sm font-semibold text-foreground">{t.footer.follow}</h2>
          <ul className="mt-3 flex items-center gap-2">
            {activeSocialLinks.map((link) => {
              const Icon = icons[link.platform];
              return (
                <li key={link.platform}>
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={link.label}
                    className="flex size-10 items-center justify-center rounded-xl border border-border bg-card text-muted-foreground transition-colors hover:border-accent hover:text-accent"
                  >
                    {Icon ? <Icon className="size-4" /> : link.label}
                  </a>
                </li>
              );
            })}
          </ul>
        </div>
      </Container>

      <div className="border-t border-border">
        <Container className="flex flex-col items-center gap-4 py-8 text-center">
          <h2 className="text-xs font-semibold tracking-[0.2em] text-muted-foreground uppercase">
            {t.footer.affiliation}
          </h2>
          <AffiliationLogos size="sm" className="justify-center" />
        </Container>
      </div>

      <div className="border-t border-border">
        <Container className="py-5 text-center text-xs text-muted-foreground">
          {t.footer.copyright} — {year}
        </Container>
      </div>

    </footer>
  );
}
