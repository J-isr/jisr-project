import { Link } from "@tanstack/react-router";
import { X } from "lucide-react";
import { useEffect } from "react";
import { primaryNavItems } from "@/config/navigation";
import { clubConfig } from "@/config/club";
import { useLanguage } from "@/hooks/useLanguage";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/common/Logo";
import { LanguageSwitcher } from "@/components/common/LanguageSwitcher";
import { ThemeToggle } from "@/components/common/ThemeToggle";
import { SearchButton } from "@/components/common/SearchButton";
import { AuthMenu } from "@/components/common/AuthMenu";

interface MobileMenuProps {
  open: boolean;
  onClose: () => void;
  onOpenSearch: () => void;
}

export function MobileMenu({ open, onClose, onOpenSearch }: MobileMenuProps) {
  const { t } = useLanguage();

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 md:hidden">
      <button
        type="button"
        aria-label={t.nav.close}
        onClick={onClose}
        className="absolute inset-0 bg-foreground/40 backdrop-blur-sm"
      />
      <nav
        aria-label={t.nav.menu}
        className="absolute inset-x-0 top-0 rounded-b-3xl bg-background p-6 shadow-[var(--shadow-lift)]"
      >
        <div className="flex items-center justify-between">
          <Logo />
          <Button variant="ghost" size="icon" onClick={onClose} aria-label={t.nav.close}>
            <X className="size-4" aria-hidden="true" />
          </Button>
        </div>
        <ul className="mt-6 flex flex-col gap-1">
          {primaryNavItems.map((item) => (
            <li key={item.to}>
              <Link
                to={item.to}
                onClick={onClose}
                className="block rounded-xl px-3 py-3 text-base font-medium text-foreground transition-colors hover:bg-secondary"
                activeProps={{ className: "bg-secondary text-brand-blue" }}
                activeOptions={{ exact: item.to === "/" }}
              >
                {t.nav[item.key]}
              </Link>
            </li>
          ))}
        </ul>

        <div className="mt-4 flex items-center gap-1 border-t border-border pt-4">
          <SearchButton onClick={onOpenSearch} />
          <ThemeToggle />
          <LanguageSwitcher />
        </div>

        <div className="mt-4 border-t border-border pt-4">
          <AuthMenu layout="stacked" onNavigate={onClose} />
        </div>


        <Button asChild variant="gold" size="lg" className="mt-4 w-full">
          <a href={clubConfig.joinFormUrl} target="_blank" rel="noopener noreferrer">
            {t.nav.join}
          </a>
        </Button>
      </nav>
    </div>
  );
}
