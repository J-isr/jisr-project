import type { ReactNode } from "react";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import { CodeModeToggle } from "@/components/common/CodeModeToggle";
import { useLanguage } from "@/hooks/useLanguage";

export function SiteLayout({ children }: { children: ReactNode }) {
  const { t, dir } = useLanguage();

  return (
    <div dir={dir} className="flex min-h-screen flex-col overflow-x-hidden">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
      >
        {t.common.skipToContent}
      </a>
      <Navbar />
      <main id="main" className="flex-1">
        {children}
      </main>
      <Footer />
      <CodeModeToggle />
    </div>
  );
}
