import { Link } from "@tanstack/react-router";
import { Menu } from "lucide-react";
import { useState } from "react";
import { primaryNavItems } from "@/config/navigation";
import { clubConfig } from "@/config/club";
import { useLanguage } from "@/hooks/useLanguage";
import { Container } from "@/components/common/Container";
import { Logo } from "@/components/common/Logo";
import { LanguageSwitcher } from "@/components/common/LanguageSwitcher";
import { ThemeToggle } from "@/components/common/ThemeToggle";
import { SearchButton } from "@/components/common/SearchButton";
import { SearchModal } from "@/components/common/SearchModal";
import { MobileMenu } from "./MobileMenu";
import { AuthMenu } from "@/components/common/AuthMenu";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const { t } = useLanguage();
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur-md">
      <Container className="flex h-16 items-center justify-between gap-4">
        <Link to="/" aria-label={clubConfig.nameEn}>
          <Logo />
        </Link>

        <nav aria-label={t.nav.menu} className="hidden md:block">
          <ul className="flex items-center gap-1">
            {primaryNavItems.map((item) => (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className="rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                  activeProps={{ className: "text-brand-blue bg-secondary" }}
                  activeOptions={{ exact: item.to === "/" }}
                >
                  {t.nav[item.key]}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-1">
          <SearchButton onClick={() => setSearchOpen(true)} />
          <ThemeToggle />
          <LanguageSwitcher />
          <div className="hidden md:flex">
            <AuthMenu />
          </div>
          <Button asChild variant="gold" size="sm" className="hidden lg:inline-flex">
            <a href={clubConfig.joinFormUrl} target="_blank" rel="noopener noreferrer">
              {t.nav.join}
            </a>
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            aria-label={t.nav.menu}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(true)}
          >
            <Menu className="size-4" aria-hidden="true" />
          </Button>
        </div>
      </Container>

      <MobileMenu
        open={menuOpen}
        onClose={() => setMenuOpen(false)}
        onOpenSearch={() => {
          setMenuOpen(false);
          setSearchOpen(true);
        }}
      />
      <SearchModal open={searchOpen} onOpenChange={setSearchOpen} />
    </header>
  );
}
