import { Search } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";
import { Button } from "@/components/ui/button";

/** Placeholder search entry point — wiring comes in a later phase. */
export function SearchButton({ onClick }: { onClick?: () => void }) {
  const { t } = useLanguage();

  return (
    <Button type="button" variant="ghost" size="icon" onClick={onClick} aria-label={t.common.search}>
      <Search className="size-4" aria-hidden="true" />
    </Button>
  );
}
