import { cn } from "@/lib/utils";
import { clubConfig } from "@/config/club";
import { brandingConfig } from "@/config/branding";
import { useLanguage } from "@/hooks/useLanguage";

interface LogoProps {
  className?: string;
  markClassName?: string;
  showWordmark?: boolean;
  inverted?: boolean;
}

/** Official JISR lockup — image asset, never redrawn. */
export function Logo({ className, markClassName, showWordmark = true, inverted = false }: LogoProps) {
  const { language } = useLanguage();
  const alt = language === "ar" ? brandingConfig.jisr.altAr : brandingConfig.jisr.altEn;

  return (
    <span className={cn("flex items-center gap-2.5", className)}>
      <img
        src={brandingConfig.jisr.src}
        alt={alt}
        loading="eager"
        className={cn("h-9 w-auto max-w-[140px] shrink-0 rounded-lg object-contain", markClassName)}
      />
      {showWordmark ? (
        <span
          className={cn(
            "hidden font-display text-lg font-bold tracking-tight sm:inline",
            inverted ? "text-primary-foreground" : "text-foreground",
          )}
        >
          {clubConfig.nameEn} <span className="text-accent">|</span> {clubConfig.nameAr}
        </span>
      ) : null}
    </span>
  );
}
