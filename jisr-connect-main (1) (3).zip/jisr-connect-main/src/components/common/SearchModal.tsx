import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { navItems } from "@/config/navigation";
import { useLanguage } from "@/hooks/useLanguage";

interface SearchModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/**
 * Search UI shell. Content/database search is intentionally not wired yet —
 * results are page destinations only. Future sources plug into `results`.
 */
export function SearchModal({ open, onOpenChange }: SearchModalProps) {
  const { t, dir } = useLanguage();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return navItems.filter((item) => !q || t.nav[item.key].toLowerCase().includes(q));
  }, [query, t]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent dir={dir} className="max-w-lg">
        <DialogHeader className={dir === "rtl" ? "text-right" : "text-left"}>
          <DialogTitle>{t.search.title}</DialogTitle>
          <DialogDescription>{t.search.hint}</DialogDescription>
        </DialogHeader>

        <div className="relative">
          <Search
            className="pointer-events-none absolute top-1/2 size-4 -translate-y-1/2 text-muted-foreground start-3"
            aria-hidden="true"
          />
          <Input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t.search.placeholder}
            aria-label={t.search.placeholder}
            className="ps-9"
          />
        </div>

        <div>
          <p className="mb-2 text-xs font-semibold tracking-wide text-muted-foreground uppercase">
            {t.search.pages}
          </p>
          {results.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">{t.search.noResults}</p>
          ) : (
            <ul className="max-h-64 space-y-1 overflow-y-auto">
              {results.map((item) => (
                <li key={item.to}>
                  <button
                    type="button"
                    onClick={() => {
                      onOpenChange(false);
                      setQuery("");
                      void navigate({ to: item.to });
                    }}
                    className="w-full rounded-xl px-3 py-2.5 text-start text-sm font-medium text-foreground transition-colors hover:bg-secondary focus-visible:bg-secondary"
                  >
                    {t.nav[item.key]}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
