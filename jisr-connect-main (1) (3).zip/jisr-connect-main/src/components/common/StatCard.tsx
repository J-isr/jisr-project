import { Calendar, Layers, Users, type LucideIcon } from "lucide-react";
import type { StatItem } from "@/config/stats";
import { useLanguage } from "@/hooks/useLanguage";

const icons: Record<StatItem["icon"], LucideIcon> = {
  calendar: Calendar,
  users: Users,
  layers: Layers,
};

export function StatCard({ stat }: { stat: StatItem }) {
  const { language } = useLanguage();
  const Icon = icons[stat.icon];

  return (
    <div className="surface-card flex items-center gap-4 p-6">
      <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-brand-blue-soft text-brand-blue">
        <Icon className="size-5" aria-hidden="true" />
      </span>
      <div>
        <p className="font-display text-3xl font-bold text-foreground">{stat.value}</p>
        <p className="mt-1 text-sm text-muted-foreground">
          {language === "ar" ? stat.labelAr : stat.labelEn}
        </p>
      </div>
    </div>
  );
}
