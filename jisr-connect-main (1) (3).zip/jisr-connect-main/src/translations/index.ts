import { ar, type Translation } from "./ar";
import { en } from "./en";

export type Language = "ar" | "en";

export const translations: Record<Language, Translation> = { ar, en };
export type { Translation };
export const languages: Language[] = ["ar", "en"];
