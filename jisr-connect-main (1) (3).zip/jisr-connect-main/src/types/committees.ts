import type { Language } from "@/translations";

/** Bilingual text shared by all committee/department content. */
export interface Bilingual {
  ar: string;
  en: string;
}

export interface Committee {
  id: string;
  departmentId: string;
  name: Bilingual;
  description: Bilingual;
  icon?: string;
}

export interface Department {
  id: string;
  name: Bilingual;
  overview: Bilingual;
  icon?: string;
  /** Public Relations is displayed separately and prominently. */
  featured?: boolean;
  committees: Committee[];
}

export interface MatcherOption {
  id: string;
  label: Bilingual;
  /** committeeId -> score contribution */
  scores: Record<string, number>;
}

export interface MatcherQuestion {
  id: string;
  question: Bilingual;
  options: MatcherOption[];
}

export interface CommitteeMatchResult {
  committee: Committee;
  department: Department;
  score: number;
  /** Labels of the answers that produced the match, for the explanation. */
  reasons: Bilingual[];
}

export function pick(value: Bilingual, language: Language): string {
  return language === "ar" ? value.ar : value.en;
}
