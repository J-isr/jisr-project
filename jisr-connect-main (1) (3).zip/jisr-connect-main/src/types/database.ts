/**
 * Table name registry for the EXISTING JISR Supabase database.
 * These tables already exist — never recreate or modify them here.
 * Row types stay intentionally loose until the live schema is inspected.
 */
export const TABLES = {
  academyCourses: "academy_courses",
  achievements: "achievements",
  announcements: "announcements",
  certificates: "certificates",
  committeeMembers: "committee_members",
  committees: "committees",
  courseAttendance: "course_attendance",
  courseMaterials: "course_materials",
  courseRegistrations: "course_registrations",
  eventRegistrations: "event_registrations",
  events: "events",
  faq: "faq",
  gallery: "gallery",
  heroSections: "hero_sections",
  members: "members",
  news: "news",
  notifications: "notifications",
  pages: "pages",
  partners: "partners",
  projectMembers: "project_members",
  projects: "projects",
  siteSettings: "site_settings",
  socialLinks: "social_links",
  statistics: "statistics",
  trainingHours: "training_hours",
  userRoles: "user_roles",
} as const;

export type TableName = (typeof TABLES)[keyof typeof TABLES];

/** Placeholder row shape until generated types are available. */
export type Row = Record<string, unknown>;
